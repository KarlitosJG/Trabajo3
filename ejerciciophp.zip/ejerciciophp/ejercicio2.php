<html lang="es">
<head>
  <title>Ejercicio 2</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
  <center><h1>PROGRAMACION DE APLICACIONES WEB</h1></center>
  <center><h4>Mostrar en pantalla una tabla de 10 por 10 con los numeros del 1 al 100</h4></center>
<center><div>
    <?php
    echo "<center><table border=1 bgcolor=white>";
    $n=1;
    for ($n1=1; $n1<=10; $n1++)
    {
    echo "<tr>";
      for ($n2=1; $n2<=10; $n2++)
    {
      echo "<td>", $n, "</td>";
          $n=$n+1;
    }
    echo "</tr>";
    }
    echo "</table></center>";
    ?>
</div><center>
<div id="piepagina">
   <p id="textopie">Nombre del alumno: Carlos Daniel Jimenez Gomez</p>
</div>
<br>
<form action="index.php" method="post" name="Retorno">
  <input name="Accion" type="submit" id="btnregresa" value="Regresar">
</form> 
   </body>
   </html>