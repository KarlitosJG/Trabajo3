<html lang="es">
<head>
  <title>Ejercicio 4</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
    <center><h1>PROGRAMACION DE APLICACIONES WEB</h1></center>
  <center><h4>Mostrar en pantalla cual es el mayor de dos numeros</h4><center>
<center><div>
<?php
$n1=550;
$n2=5400;
if ($n1>$n2){
echo "El primer número (".$n1.") es mayor que el segundo (".$n2.")";
}
elseif ($n1==$n2){
echo "El primer número (".$n1.") es igual al segundo (".$n2.")";
}
else{
echo "El primer número (".$n1.") es menor que el segundo (".$n2.")";
}
?>
</div><center>
<div id="piepagina">
<p id="textopie">Nombre del alumno: Carlos Daniel Jimenez Gomez</p>
</div>
<br>
<form action="index.php" method="post" name="Retorno">
<input name="Accion" type="submit" id="btnregresa" value="Regresar">
</form> 
   </body>
   </html>
