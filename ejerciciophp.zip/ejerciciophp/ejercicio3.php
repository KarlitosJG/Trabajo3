<html lang="es">
<head>
  <title>Ejercicio 3</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
  <center><h1>PROGRAMACION DE APLICACIONES WEB</h1></center>
  <center><h4>Mostrar en pantalla una tabla de 1 por 10</h4></center>
  <center><div>
<?php
      echo "<center><h2>BUCLE WHILE</h2><center><br>";
      echo "<center><table border=1 bgcolor=#FFBA00>";
      for($i=0; $i<10;$i++)
      {
        echo "<tr>";
        echo "<td>";
        echo "Linea ".$i."<br>";
        echo "</td>";
        echo "<tr>";
      }
    echo "</table></center>"; 
   ?>
</div><center>
<div id="piepagina">
   <p id="textopie">Nombre del alumno: Carlos Daniel Jimenez Gomez</p>
</div>
<br>
<form action="index.php" method="post" name="Retorno">
  <input name="Accion" type="submit" id="btnregresa" value="Regresar">
</form> 
   </body>
   </html>