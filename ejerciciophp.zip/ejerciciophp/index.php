<html lang="es">
<head>
  <title>Ejercicios en PHP</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
  <center><div>
  <center><h1>VARIABLES</h1></center>
    <form action="ejercicio1.php" method="post">
    <input type="submit" id="btn1" value="Ejercicio1">
    </form> 
    <form action="ejercicio2.php" method="post" >
      <input type="submit" id="btn2" value="Ejercicio2">
    </form> 
    <form action="ejercicio3.php" method="post">
      <input type="submit" id="btn3" value="Ejercicio3">
    </form> 
    <form action="ejercicio4.php" method="post">
      <input type="submit" id="btn4" value="Ejercicio4">
    </form> 
    <form action="ejercicio5.php" method="post">
      <input type="submit" id="btn5" value="Ejercicio5">
    </form> 
  <center><img src="img/html.png" width="250px" height="250px"></center>
   </body>
   </html>   