﻿<html lang="es">
<head>
  <title>Ejercicio 4</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
    <center><h1>PROGRAMACION DE APLICACIONES WEB</h1></center>
  <center><h4>Mostrar en pantalla cual es el mayor de tres numeros</h4></center>
<center><div>  
<?php
$n1=10;
$n2=9;
$n3=7;
if (($n1 > $n2) && ($n1 > $n3)) {
   echo "El primer número (".$n1.") es el mayor";
}
 elseif (($n2 > $n1) && ($n2 > $n3)) {
echo "El segundo número (".$n2.") es el mayor";
}
 elseif (($n3 > $n1) && ($n3 > $n2)) {
 echo "El tercer número (".$n3.") es el mayor";
}

?>
</div><center>
<div id="piepagina">
<p id="textopie">Nombre del alumno: Carlos Daniel Jimenez Gomez</p>
</div>
<br>
<form action="index.php" method="post" name="Retorno">
<input name="Accion" type="submit" id="btnregresa" value="Regresar">
</form> 
   </body>
   </html>
