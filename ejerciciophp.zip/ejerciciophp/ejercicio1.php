<html lang="es">
<head>
  <title>Ejercicio 1</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
  <body>
   <center> <h1>PROGRAMACION DE APLICACIONES WEB</h1></center>
  <center><h4 >Hacer un programa que sume,reste,multiplique y divida dos variables</h4></center>
  <center><div>
      <?php
        $numero1=10;
        $numero2=12;
        
        echo "La Suma:<Br/>";
        $suma=$numero1+$numero2;
        echo "$numero1+$numero2"."<br>";
        echo "Suma = ".$suma."<br>";
        
        echo "La resta:<Br/>";
        $resta=$numero1-$numero2;
        echo "$numero1-$numero2"."<br>";
        echo "Resta = ".$resta."<br>";
        
        echo "La Multiplicacion:<Br/>";
        $multip=$numero1*$numero2;
        echo "$numero1*$numero2"."<br>";
        echo "Multiplicacion = ".$multip."<br>";
        
        echo "La division:<Br/>";
        $divicion=$numero1/$numero2;
        echo "$numero1/$numero2"."<br>";
        echo "division = ".$divicion."<br>";
      ?>
    
</div><center>
<div id="piepagina">
   <p id="textopie">Nombre del alumno: Carlos Daniel Jimenez Gomez</p>
</div>
<br>
<form action="index.php" method="post" name="Retorno">
  <input name="Accion" type="submit" id="btnregresa" value="Regresar">
</form> 
   </body>
   </html>